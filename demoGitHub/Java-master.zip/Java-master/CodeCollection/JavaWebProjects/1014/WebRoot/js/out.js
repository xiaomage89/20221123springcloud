/**
 * 把文本内容写入到浏览器端，换行的。
 * @param str
 */
function println(str) {
	document.write(str+"<br/>");
}