package org.lxy.el;
/**
 * @author menglanyingfei
 * @date 2017-3-15
 */
public class ELDemo1 {
	/**
	 * @param args
	 */
	public static String sayHello(String name) {	
		return "hello " + name;
	}
}
