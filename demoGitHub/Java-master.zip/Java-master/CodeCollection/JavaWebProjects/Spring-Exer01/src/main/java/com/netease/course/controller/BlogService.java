package com.netease.course.controller;

public interface BlogService {
    public void pressblog(String title,String content);
}
