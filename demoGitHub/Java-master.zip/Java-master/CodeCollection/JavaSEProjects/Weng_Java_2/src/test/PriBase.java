package test;
/**
 * @author menglanyingfei
 * @date 2017-8-16
 */
/*
private class Base1 {
    Base1(){
        int i = 100;
        System.out.println(i);
    }
}
public class PriBase extends Base1 {
    static int i = 200;
    public static void main(String argv[]){
        PriBase p = new PriBase();
        System.out.println(i);
    }
}
*/