package test;
/**
 * @author menglanyingfei
 * @date 2017-8-16
 */
/*
class DataServer extends Server {
    public String serverName;
    public DataServer() {
        serverName = "Customer Service";
        super(serverName);
    }
}
*/