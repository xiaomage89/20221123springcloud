package test;
/**
 * @author menglanyingfei
 * @date 2017-7-15
 */
public class StringTest {
	public static void main(String[] args) {
//		 String  s = " 我喜欢学习 Java!";
//		 System.out.println(s.length( ));
		
		int[] arr = new int[5];
		System.out.println(arr[0]); // 0
	}
}
