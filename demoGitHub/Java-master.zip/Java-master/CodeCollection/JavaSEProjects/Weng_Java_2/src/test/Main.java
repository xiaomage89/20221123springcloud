package test;
/**
 * @author menglanyingfei
 * @date 2017-7-14
 */
public class Main {
	// 取三位数的十位
	public static void main(String[] args) {
		System.out.println(115 / 10 % 10);
	}
}
