package test;
/**
 * @author menglanyingfei
 * @date 2017-8-16
 */
/*
class TestServer {
    public TestServer() { int users = 1; }
    public void inc() { users++; }
    public static void main(String[] args) {
        TestServer ts = new TestServer();
        ts.inc();
        System.out.println("Var users = "+ts.users);
    }
 }
*/