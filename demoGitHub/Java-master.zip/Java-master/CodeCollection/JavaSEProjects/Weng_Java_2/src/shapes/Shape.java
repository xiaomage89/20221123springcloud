package shapes;

import java.awt.Graphics;

/**
 * @author menglanyingfei
 * @date 2017-7-15
 */
public abstract class Shape {
	public abstract void draw(Graphics g);
	abstract void move(Graphics g);
	//public abstract void move(Graphics g);
}























