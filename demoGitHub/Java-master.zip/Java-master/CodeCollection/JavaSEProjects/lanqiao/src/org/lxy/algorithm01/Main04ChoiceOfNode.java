package org.lxy.algorithm01;
/**
 * @author menglanyingfei
 * @date 2017-3-14
 */
public class Main04ChoiceOfNode {
	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
