package org.lxy.algorithm01;
/**
 * @author menglanyingfei
 * @date 2017-3-15
 */
public class Main06Kruskal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
