package org.lxy.algorithm01;
/**
 * @author menglanyingfei
 * @date 2017-3-18
 */
public class Main42_Score {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("yes");
	}

}
