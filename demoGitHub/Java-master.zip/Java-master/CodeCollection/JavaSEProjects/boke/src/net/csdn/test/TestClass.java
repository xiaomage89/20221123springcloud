package net.csdn.test;					// 包的命名
/**
 * @author menglanyingfei
 * @date 2017-2-8
 */
public class TestClass {					// 类的命名(接口的命名同类)
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		final int MAX_VALUE = 100; // 常量的命名
		double minValue = 6.6;		// 变量的命名(方法的命名同变量)
		System.out.println("MAX_VALUE = " + MAX_VALUE);
		System.out.println("minValue = " + minValue);
	}

}
