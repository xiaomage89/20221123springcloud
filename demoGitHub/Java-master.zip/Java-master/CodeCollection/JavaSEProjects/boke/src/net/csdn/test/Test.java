package net.csdn.test;
/**
 * @author menglanyingfei
 * @date 2017-3-8
 */
public class Test {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s = "abcde";
		System.out.println(s.substring(0, 2));	// ab
		// 中文测试
		System.out.println("中文格式");
	}

}
