package org.lxy.javase_2;
/**
 * @author menglanyingfei
 * @date 2017-3-9
 */
public class ComparisonOfBasicDataTypes {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a = 10;
		int b = 10;
		System.out.println(a == b);	// true
	}
}
