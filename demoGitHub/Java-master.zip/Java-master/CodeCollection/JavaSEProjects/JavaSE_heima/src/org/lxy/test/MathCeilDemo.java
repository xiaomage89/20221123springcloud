package org.lxy.test;
/**
 * @author menglanyingfei
 * @date 2017-5-15
 */
public class MathCeilDemo {
	public static void main(String[] args) {
		double d = Math.ceil(1.4);
		System.out.println(d);
	}
}
