package org.demo.statictest;
/**
 * @author menglanyingfei
 * @date 2017-5-14
 */
public class Test2 {
    
    static{
        System.out.println("test static 1");
    }
    public static void main(String[] args) {
         
    }
     
    static{
        System.out.println("test static 2");
    }
}
