package test;

/**
 * ����String
 *
 * @Author menglanyingfei
 * @Created on 2017.12.18 12:31
 */
public class TestString {
    public static void main(String[] args) {
        String str = "1.0";
        System.out.println(str.substring(0, 1));
    }
}
