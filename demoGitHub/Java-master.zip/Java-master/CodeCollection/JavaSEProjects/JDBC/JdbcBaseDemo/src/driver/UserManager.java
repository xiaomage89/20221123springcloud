package driver;

import view.Menu;

public class UserManager {

    public static void main(String[] args) {
        new Menu();
    }

}
