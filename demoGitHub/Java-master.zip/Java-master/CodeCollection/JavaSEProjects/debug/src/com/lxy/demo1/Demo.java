package com.lxy.demo1;

//import java.io.FileOutputStream;
//import java.util.ArrayList;
//import java.util.List;

public class Demo {
	
	public void run() throws Exception {
//		FileOutputStream fos = new FileOutputStream("");
//		List list = new ArrayList();
		
		
		
	}
}
