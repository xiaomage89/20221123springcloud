package com.lxy.staticimport;

import static java.lang.System.out;

import org.junit.Test;

/**
 * 静态导入
 * @author 15072
 *
 */
public class StaticTest {

	@Test
	public void run() {
		out.print("haha");
	}

}
