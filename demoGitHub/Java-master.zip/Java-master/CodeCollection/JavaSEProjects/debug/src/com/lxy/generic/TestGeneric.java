package com.lxy.generic;

import java.util.ArrayList;
import java.util.List;

public class TestGeneric {
	/**
	 *只要两边有泛型，必须一致
	 */
//	List list1 = new ArrayList();
//	List<String> list2 = new ArrayList();
//	List list3 = new ArrayList<String>();
	List<String> list4 = new ArrayList<String>();
// 这是错误的写法！
//	List<Object> list5 = new ArrayList<String>();
//	List<String> list6 = new ArrayList<Object>();
//	public void demo1(List list) {
//		
//	}
//	
//	public void demo() {
//		demo1(new ArrayList<String>());
//	}
	
	
	
	
	
	
	
	
	
	
	
}
