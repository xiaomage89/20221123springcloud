package com.lxy.generic;

public class GenericClass <T> {
	// 可以用T
//	private T t;
	
	public void run(T t2) {
//		T t3;
	}
}
