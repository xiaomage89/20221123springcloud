package org.lxy.object;
/**
 * @author menglanyingfei
 * @date 2017-2-17
 */
public class Demo2_ToString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p = new Person("李小阳", 20);
		System.out.println(p.toString());
		System.out.println(p);
	}

}
